import React from 'react';
import ReactDOM from 'react-dom';
import AppReviewsService from './components/AppReviewsService.jsx';

ReactDOM.render(<AppReviewsService />, document.getElementById('AppReviewsService'));
