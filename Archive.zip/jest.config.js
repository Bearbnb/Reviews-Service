module.exports = {
  verbose: true,
  setupTestFrameworkScriptFile: '<rootDir>tests/configTests.js',
  moduleNameMapper: {
    '\\.(css)$': 'identity-obj-proxy',
  },
};